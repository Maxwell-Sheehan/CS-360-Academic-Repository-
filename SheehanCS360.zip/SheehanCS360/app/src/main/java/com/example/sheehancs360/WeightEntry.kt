package com.example.sheehancs360

data class WeightEntry(
    val date: String,
    val weight: Float
)
