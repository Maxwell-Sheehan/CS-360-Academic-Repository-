package com.example.sheehancs360

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import android.widget.EditText
import java.text.SimpleDateFormat
import java.util.*

class DataActivity : AppCompatActivity() {

    lateinit var db: AppDatabase
    lateinit var adapter: WeightAdapter
    lateinit var chart: LineChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data)

        db = AppDatabase(this)

        val recycler = findViewById<RecyclerView>(R.id.recyclerViewData)
        chart = findViewById(R.id.weightChart)
        val addBtn = findViewById<Button>(R.id.buttonAddData)

        adapter = WeightAdapter(db.getWeights()) { pos ->
            db.deleteWeight(pos)
            adapter.items.removeAt(pos)
            adapter.notifyDataSetChanged()
            loadGraph()
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        addBtn.setOnClickListener { addWeightDialog() }

        loadGraph()
    }

    private fun addWeightDialog() {
        val input = EditText(this)
        input.hint = "Enter weight"

        AlertDialog.Builder(this)
            .setTitle("Add Weight")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val weight = input.text.toString().toFloat()
                val date = SimpleDateFormat("MM/dd", Locale.US).format(Date())
                db.addWeight(date, weight)
                adapter.items.add(WeightEntry(date, weight))
                adapter.notifyDataSetChanged()
                loadGraph()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadGraph() {
        val entries = mutableListOf<Entry>()
        val weights = db.getWeights()

        weights.forEachIndexed { index, item ->
            entries.add(Entry(index.toFloat(), item.weight))
        }

        val dataSet = LineDataSet(entries, "Weight")
        chart.data = LineData(dataSet)
        chart.invalidate()
    }
}
