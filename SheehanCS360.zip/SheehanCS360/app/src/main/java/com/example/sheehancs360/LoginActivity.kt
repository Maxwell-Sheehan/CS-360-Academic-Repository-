package com.example.sheehancs360

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        db = AppDatabase(this)

        val user = findViewById<EditText>(R.id.editTextUsername)
        val pass = findViewById<EditText>(R.id.editTextPassword)
        val loginBtn = findViewById<Button>(R.id.buttonLogin)
        val createBtn = findViewById<Button>(R.id.buttonCreateAccount)

        loginBtn.setOnClickListener {
            if (db.checkLogin(user.text.toString(), pass.text.toString())) {
                startActivity(Intent(this, DataActivity::class.java))
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show()
            }
        }

        createBtn.setOnClickListener {
            if (db.createUser(user.text.toString(), pass.text.toString())) {
                Toast.makeText(this, "Account created!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
