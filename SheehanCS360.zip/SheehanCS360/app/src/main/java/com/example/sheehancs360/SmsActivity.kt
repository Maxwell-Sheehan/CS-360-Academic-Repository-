package com.example.sheehancs360

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class SmsActivity : AppCompatActivity() {

    val SMS_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        val status = findViewById<TextView>(R.id.textSmsStatus)
        val btn = findViewById<Button>(R.id.buttonRequestSms)

        btn.setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_CODE
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)

        val status = findViewById<TextView>(R.id.textSmsStatus)

        if (code == SMS_CODE) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
                status.text = "SMS Enabled"
                SmsManager.getDefault().sendTextMessage(
                    "5550000",
                    null,
                    "Your weight goal alert!",
                    null,
                    null
                )
            } else {
                status.text = "Permission Denied"
            }
        }
    }
}
