package com.example.sheehancs360
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightAdapter(
    private val items: MutableList<WeightEntry>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

    inner class WeightViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val dateText: TextView = view.findViewById(R.id.textItemName)
        val weightText: TextView = view.findViewById(R.id.textItemQty)
        val deleteBtn: Button = view.findViewById(R.id.buttonDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false)
        return WeightViewHolder(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: WeightViewHolder, position: Int) {
        val item = items[position]
        holder.dateText.text = item.date
        holder.weightText.text = item.weight.toString()

        holder.deleteBtn.setOnClickListener {
            onDelete(position)
        }
    }
}
