package com.example.sheehancs360;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.Editable;
import android.text.TextWatcher;

public class MainActivity extends AppCompatActivity {

    EditText nameText;
    Button buttonSayHello;
    TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI elements
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        // Disable button at start
        buttonSayHello.setEnabled(false);

        // Enable/disable button based on content
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button only if text exists
                buttonSayHello.setEnabled(s.length() > 0);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    // Called when buttonSayHello is pressed
    public void SayHello(View view) {

        // Get content from nameText
        String name = nameText.getText().toString().trim();

        // If empty, exit function
        if (name.isEmpty()) {
            return;
        }

        // Otherwise show greeting
        textGreeting.setText("Hello " + name);
    }
}
