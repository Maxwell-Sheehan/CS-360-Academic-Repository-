package com.example.sheehancs360

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase(context: Context) :
    SQLiteOpenHelper(context, "fitness.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT UNIQUE, " +
                    "password TEXT)"
        )

        db.execSQL(
            "CREATE TABLE weights (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "date TEXT, " +
                    "weight REAL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, newV: Int) {}

    // ----------------- USER FUNCTIONS -----------------

    fun createUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("username", username)
        values.put("password", password)
        return db.insert("users", null, values) > 0
    }

    fun checkLogin(username: String, password: String): Boolean {
        val db = readableDatabase
        val c = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )
        val ok = c.count > 0
        c.close()
        return ok
    }

    // ----------------- WEIGHT FUNCTIONS -----------------

    fun addWeight(date: String, weight: Float) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("date", date)
        values.put("weight", weight)
        db.insert("weights", null, values)
    }

    fun getWeights(): MutableList<WeightEntry> {
        val list = mutableListOf<WeightEntry>()
        val db = readableDatabase
        val c = db.rawQuery("SELECT date, weight FROM weights", null)

        while (c.moveToNext()) {
            list.add(
                WeightEntry(
                    date = c.getString(0),
                    weight = c.getFloat(1)
                )
            )
        }
        c.close()
        return list
    }

    fun deleteWeight(id: Int) {
        val db = writableDatabase
        db.delete("weights", "id=?", arrayOf(id.toString()))
    }
}
